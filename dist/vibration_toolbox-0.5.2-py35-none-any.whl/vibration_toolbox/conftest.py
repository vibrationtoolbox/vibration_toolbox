import numpy as np

np.set_printoptions(precision=2, suppress=True)
print('Running conftest.py')

