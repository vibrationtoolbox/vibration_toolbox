function vdp=vtb10_expend(x,v)
% Example function file for the Van der Pol equation simulation.
vdp=-sin(x)-.001*v;
