function z = VTB9_3(rkf,u,t,x0)
%VTB9_3 has been grandfathered. Please use VTB1_3 in the future.

disp('VTB9_3 has been grandfathered. Please use VTB1_3 in the future.')




%Automatically check for updates
vtbchk
