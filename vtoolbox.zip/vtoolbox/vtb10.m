% VTB10
%
% VTB10_1 plots the phase plan of a second order differential
%         equation using finite differences.  See VTB10ex.
% VTB10ex example function file for VTB10_1.  Type help 
%         VTB10_1 for instructions on running this example.


%Automatically check for updates
vtbchk
