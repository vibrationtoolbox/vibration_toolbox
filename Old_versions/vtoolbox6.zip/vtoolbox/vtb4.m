function vtb4

% VTB4
%
% VTB4_1 Natural frequencies and eigenvectors for an undamped
%        system.
% VTB4_2 Free response of an undamped system.
% VTB4_3 solves for the natural frequencies, damping ratios, 
%        and mode shapes of a linear second order matrix (LSOM)
%        form system.  (M,C,K)
