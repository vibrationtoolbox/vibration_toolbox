function vdp=vdp(x,xd)
% Example function file for the Van der Pol equation simulation.
vdp=-(.2*(x.^2-1).*xd+x);
