% Displays updates to Engineering Vibration Toolbox after 1/1/98
% Launches browser to show current updates available online
%
% If Matlab is not set up to launch your browser, connect to
% http://www.cs.wright.edu/people/faculty/jslater/vtoolbox/vtoolbox/vtbud.txt
% manually.
%

type vtbud.txt
web http://www.cs.wright.edu/people/faculty/jslater/vtoolbox/vtoolbox/vtbud.txt;
