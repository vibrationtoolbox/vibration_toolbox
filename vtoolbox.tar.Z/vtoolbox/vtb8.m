% VTB8
% This help file is extensive.  I suggest you print out the
% file named vtb8read.txt.  Alternatively, use "type vtb8read.txt"
